<?php
interface Product
{}
