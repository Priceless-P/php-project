<?php
//database details
define('DB_HOST', 'localhost');
define('DB_NAME', 'optizuib_Phpproject');
define('DB_USER', 'optizuib_user');
define('DB_PASSWORD', 'pass111$*?');

//App Root
define('APPROOT', dirname(dirname(__FILE__)));
//URL Root
define('URLROOT', 'https://phpproject.optimumdelivery.net');
//SITENAME
define('SITENAME', 'Scandiweb Project');