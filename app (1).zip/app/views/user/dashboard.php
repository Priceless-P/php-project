<?php
require_once APPROOT.'/views/inc/header.php'; ?>
<h1><? echo "Welcome to Dashboard"; ?></h1>
<?php
require_once APPROOT.'/views/inc/footer.php'; ?>