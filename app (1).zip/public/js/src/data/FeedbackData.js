const FeedbackData = [
    {
      id:1,
      rating: 10,
      text: 'orem ipsum dolor sit amet, consectetur adipiscing elit. Ut enim ante, volutpat euismod metus eu, ornare ultricies metus. Suspendisse felis libero, varius id nisl mollis, tincidunt ultrices arcu. Aenean venenatis turpis vitae cursus posuere. Pellentesque aliquet sodales odio, ac vestibulum quam pretium in. ',
    },
    {
      id:2,
      rating: 9,
      text: 'orem ipsum dolor sit amet, consectetur adipiscing elit. Ut enim ante, volutpat euismod metus eu, ornare ultricies metus. Suspendisse felis libero, varius id nisl mollis, tincidunt ultrices arcu. Aenean venenatis turpis vitae cursus posuere. Pellentesque aliquet sodales odio, ac vestibulum quam pretium in. ',
    },
    {
      id:3,
      rating: 8,
      text: 'orem ipsum dolor sit amet, consectetur adipiscing elit. Ut enim ante, volutpat euismod metus eu, ornare ultricies metus. Suspendisse felis libero, varius id nisl mollis, tincidunt ultrices arcu. Aenean venenatis turpis vitae cursus posuere. Pellentesque aliquet sodales odio, ac vestibulum quam pretium in. ',
    },
  ]

export default FeedbackData;