<?php
require_once '../app/autoload.php';

$init = new Core;