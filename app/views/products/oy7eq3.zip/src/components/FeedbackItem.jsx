import "../styles.css";

function FeedbackItem(){

return(
 <>
<p> FeedbackItem will go here</p>
 </>
)
}
export default FeedbackItem;