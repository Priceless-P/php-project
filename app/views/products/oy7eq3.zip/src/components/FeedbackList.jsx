import "../styles.css";
import FeedbackItem from "./FeedbackItem"

function FeedbackList(Feedback){

return(
  <div>

  </div>
)
}
export default FeedbackList;