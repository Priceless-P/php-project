import "../styles.css";

function Header(){

return(
  <div className='header'>
  <p>Feedback UI </p>
  </div>
)
}
export default Header;