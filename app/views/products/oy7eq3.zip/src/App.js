import { useState } from 'react';
import "./styles.css";
import Header from "./components/Header"
import FeedbackData from "./data/FeedbackData";
import FeedbackList from "./components/FeedbackList"

export default function App() {

  const [Feedback, setFeedback] = useState(FeedbackData);
  return (
    <div className="App">
    <>
    <Header />
      <h1>Feedback Survey</h1>
      <p>Welcome to Feedback Survey</p>
      <FeedbackList Feedback={Feedback}/>
    </>
    </div>
  );
}
